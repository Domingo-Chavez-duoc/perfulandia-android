package com.domichav.perfulandia.repository;

public class AuthPerfulandiaRepository {
}
