package com.domichav.perfulandia.data.local

data class Account(
    val name: String,
    val email: String,
    val password: String,
    val avatarPath: String? = null
)